// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {


        ProductModel.productBuilder(0,5).
//                setProductID(0).
                setProductName("X5 Pro").
                setProductModel("Pocophone").
                setProductPicture("D:/images/pocoImage.jpg").
                setUnitPrices(1499.99).
                setUnitsInStock(100).
                setUnitsOnOrder(20).
                setReorderLevel(2).
                setDiscontinued(false).build();

        System.out.println("Insertar:\n"+producto.insertProduct());
        System.out.println("Actualizar:\n"+producto.updateProduct());
        System.out.println("Eliminar:\n"+producto.deleteProduct());

    }
}