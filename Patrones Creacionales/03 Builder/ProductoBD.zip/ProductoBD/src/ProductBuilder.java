public class ProductBuilder {
    private int productID;
    private int lastProductID = 0;
    private String productName;
    private String productModel;
    private String productPicture;
    private double unitPrices;
    private int unitsInStock = 0;
    private int unitsOnOrder = 0;
    private int reorderLevel = 0;
    private boolean discontinued;

    public ProductBuilder(int productID, String productName, String productModel,
                   String productPicture, double unitPrices, boolean discontinued) {
        this.productID = productID;
        this.productName = productName;
        this.productModel = productModel;
        this.productPicture = productPicture;
        this.unitPrices = unitPrices;
        this.discontinued = discontinued;
    }

    // Métodos para construir el objeto
    private int generateProductID() {
        // Lógica para generar el ID autoincremental
        lastProductID ++;
        return lastProductID;
    }
    public ProductBuilder setProductID(int productID) {
        if(productID<0){
            this.productID = generateProductID();
        }else {
            this.productID = productID;
        }
        return this;
    }

    public ProductBuilder setProductName(String productName) {
        this.productName = productName;
        return this;
    }

    public ProductBuilder setProductModel(String productModel) {
        this.productModel = productModel;
        return this;
    }

    public ProductBuilder setProductPicture(String productPicture) {
        this.productPicture = productPicture;
        return this;
    }

    public ProductBuilder setUnitPrices(double unitPrices) {
        this.unitPrices = unitPrices;
        return this;
    }
    public ProductBuilder setUnitsInStock(int unitsInStock) {
        this.unitsInStock = unitsInStock;
        return this;
    }

    public ProductBuilder setUnitsOnOrder(int unitsOnOrder) {
        this.unitsOnOrder = unitsOnOrder;
        return this;
    }

    public ProductBuilder setReorderLevel(int reorderLevel) {
        this.reorderLevel = reorderLevel;
        return this;
    }

    public ProductBuilder setDiscontinued(boolean discontinued) {
        this.discontinued = discontinued;
        return this;
    }

    // Método para construir el objeto ProductModel
    public ProductModel build() {
        return new ProductModel(this);
    }
}
