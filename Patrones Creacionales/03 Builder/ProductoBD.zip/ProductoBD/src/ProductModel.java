public class ProductModel {

    private int productID = 0;
    private String productName;
    private String productModel;
    private String productPicture;
    private double unitPrices;
    private int unitsInStock;
    private int unitsOnOrder;
    private int reorderLevel;
    private boolean discontinued;


     // Constructor privado para utilizar el Builder

    public ProductModel(ProductBuilder builder) {
        this.productID = builder.productID;
        builder.setProductName(this.productName);
        builder.setProductModel(this.productModel);
        builder.setProductPicture(this.productPicture);
        builder.setUnitPrices(this.unitPrices);
        builder.setUnitsInStock(this.unitsInStock);
        builder.setUnitsOnOrder(this.unitsOnOrder);
        builder.setReorderLevel(this.reorderLevel);
        builder.setDiscontinued(this.discontinued);

    }

    public int getProductID() {
        return productID;
    }

    public String getProductName() {
        return productName;
    }

    public String getProductModel() {
        return productModel;
    }

    public String getProductPicture() {
        return productPicture;
    }

    public double getUnitPrices() {
        return unitPrices;
    }

    public int getUnitsInStock() {
        return unitsInStock;
    }

    public int getUnitsOnOrder() {
        return unitsOnOrder;
    }

    public int getReorderLevel() {
        return reorderLevel;
    }

    public boolean isDiscontinued() {
        return discontinued;
    }

    // Método para insertar un producto
        public String insertProduct() {
            String sqlQuery = "INSERT INTO products (ProductID, ProductName, ProductModel, ProductPicture, UnitPrices, Discontinued) VALUES ";
            sqlQuery += "(" + productID + ", '" + productName + "', '" + productModel + "', '" + productPicture + "', " + unitPrices + ", " +
                     "', " + unitsInStock + ", " +"', " + unitsOnOrder + ", "+"', " + reorderLevel +"', "+
                    discontinued + ")";
            return sqlQuery;
        }

        // Método para actualizar un producto
        public String updateProduct() {
            String sqlQuery = "UPDATE products SET ";
            sqlQuery += "ProductName = '" + productName + "', ";
            sqlQuery += "ProductModel = '" + productModel + "', ";
            sqlQuery += "ProductPicture = '" + productPicture + "', ";
            sqlQuery += "UnitPrices = " + unitPrices + ", ";
            sqlQuery += "UnitsInStock = " + unitsInStock + ", ";
            sqlQuery += "UnitsOnOrder = " + unitsOnOrder + ", ";
            sqlQuery += "ReorderLevel = " + reorderLevel + ", ";
            sqlQuery += "Discontinued = " + discontinued;
            sqlQuery += " WHERE ProductID = " + productID;
            return sqlQuery;
        }

        // Método para eliminar un producto
        public String deleteProduct() {
            String sqlQuery = "DELETE FROM products WHERE ProductID = " + productID;
            return sqlQuery;
        }


}
